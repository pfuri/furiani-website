<?php

/*
 * Created by Pixel-Mafia
 * www.pixel-mafia.com
*/
if (!class_exists('photberryQuickContact'))
{
    class photberryQuickContact extends WP_Widget
    {
        public function __construct()
        {
            parent::__construct(
                'photberryQuickContact',
                'Quick Contact (PM)',
                array('description' => '')
            );
        }

        public function update($new_instance, $old_instance)
        {
            $instance = $old_instance;

            $instance['title'] = esc_attr($new_instance['title']);
            $instance['address'] = $new_instance['address'];
            $instance['phone'] = $new_instance['phone'];
            $instance['email'] = $new_instance['email'];
            $instance['description'] = $new_instance['description'];

            return $instance;
        }

        public function form($instance)
        {
            $default_values = array(
                'title' => '',
                'description' => '',
                'address' => '20 Jay Street, Suite 404, Brooklyn, NY 11201',
                'phone' => '+1 (800) 456 37 96',
                'email' => 'info@company.com'
            );

            $instance = wp_parse_args((array)$instance, $default_values);

            ?>
            <p class="photberry_widget">
                <label>
                    <?php echo esc_html__('Title', 'photberry'); ?>:
                </label>
                <input class="widefat"
                       type="text"
                       id="<?php echo esc_attr($this->get_field_id('title')); ?>"
                       name="<?php echo esc_attr($this->get_field_name('title')); ?>"
                       value="<?php echo esc_attr($instance['title']); ?>"
                />
                <label>
                    <?php echo esc_html__('Description', 'photberry'); ?>:
                </label>
                <textarea class="widefat"
                       id="<?php echo esc_attr($this->get_field_id('description')); ?>"
                       name="<?php echo esc_attr($this->get_field_name('description')); ?>"
                ><?php echo $instance['description']; ?></textarea>
                <label>
                    <?php echo esc_html__('Address', 'photberry'); ?>:
                </label>
                <input class="widefat"
                       type="text"
                       id="<?php echo esc_attr($this->get_field_id('address')); ?>"
                       name="<?php echo esc_attr($this->get_field_name('address')); ?>"
                       value="<?php echo $instance['address']; ?>"
                />
                <label>
                    <?php echo esc_html__('Phone', 'photberry'); ?>:
                </label>
                <input class="widefat"
                       type="text"
                       id="<?php echo esc_attr($this->get_field_id('phone')); ?>"
                       name="<?php echo esc_attr($this->get_field_name('phone')); ?>"
                       value="<?php echo $instance['phone']; ?>"
                />
                <label>
                    <?php echo esc_html__('Email', 'photberry'); ?>:
                </label>
                <input class="widefat"
                       type="text"
                       id="<?php echo esc_attr($this->get_field_id('email')); ?>"
                       name="<?php echo esc_attr($this->get_field_name('email')); ?>"
                       value="<?php echo $instance['email']; ?>"
                />
            </p>
            <?php
        }

        public function widget($args, $instance)
        {
            extract($args);

            echo $before_widget;
            if ($instance['title'] !== '') {
                echo $before_title;
                echo apply_filters('widget_title', $instance['title']);
                echo $after_title;
            }

            echo '
            <div class="photberry_quick_contact">
                <div class="photberry_inner_qc">';
                    if ($instance['description'] !== '') {
                        echo '<div class="photberry_qc_widget_descr">' . $instance['description'] . '</div>';
                    }
                    if ($instance['address'] !== '') {
                        echo '<div class="photberry_qc_widget_address">'. esc_html__('Address', 'photberry') .': ' . $instance['address'] . '</div>	';
                    }
                    if ($instance['phone'] !== '') {
                        echo '<div class="photberryqc_widget_phone">'. esc_html__('Phone', 'photberry') .': ' . $instance['phone'] . '</div>';
                    }
                    if ($instance['email'] !== '') {
                        echo '<div class="photberry_qc_widget_email"><a href="mailto:'. esc_html($instance['email']) .'">'. esc_html__('Email', 'photberry') .': ' . $instance['email'] . '</a></div>';
                    }
            echo '
                </div>
            </div>
            ';

            echo $after_widget;
        }
    }
}