<?php
/*
Plugin Name: Pixel-Mafia Photberry Custom Post Types
Plugin URI: http://pixel-mafia.com
Description: Register Photberry Custom Post Types.
Version: 1.2
Author: Pixel-Mafia
Author URI: http://pixel-mafia.com
*/

function photberry_custom_post_types()
{
    # Portfolio
	$photberry_portfolio_name = esc_attr(get_theme_mod('portfolio_pt_name', 'Portfolio'));
	$photberry_portfolio_slug = esc_attr(get_theme_mod('portfolio_pt_slug', 'portfolio'));
	$photberry_portfolio_tax = esc_attr(get_theme_mod('portfolio_pt_tax', 'portfolio-category'));
	register_post_type('pm-portfolio', array(
            'label' => $photberry_portfolio_name,
            'public' => true,
            'show_ui' => true,
            'show_in_nav_menus' => true,
            'rewrite' => array(
                'slug' => $photberry_portfolio_slug,
                'with_front' => false
            ),
            'hierarchical' => true,
            'menu_position' => 4,
            'supports' => array(
                'title',
                'editor',
                'thumbnail',
                'excerpt',
                'comments',
                'post-formats'
            )
        )
    );
	register_taxonomy($photberry_portfolio_tax, 'pm-portfolio', array('hierarchical' => true, 'label' => 'Category', 'singular_name' => 'Category'));

    # Albums
	$photberry_albums_name = esc_attr(get_theme_mod('albums_pt_name', 'Albums'));
	$photberry_albums_slug = esc_attr(get_theme_mod('albums_pt_slug', 'albums'));
	$photberry_albums_tax = esc_attr(get_theme_mod('albums_pt_tax', 'albums-category'));
    register_post_type('pm-albums', array(
            'label' => $photberry_albums_name,
            'public' => true,
            'show_ui' => true,
            'show_in_nav_menus' => true,
            'rewrite' => array(
                'slug' => $photberry_albums_slug,
                'with_front' => false
            ),
            'hierarchical' => true,
            'menu_position' => 4,
            'supports' => array(
                'title',
                'thumbnail'
            )
        )
    );
	register_taxonomy($photberry_albums_tax, 'pm-albums', array('hierarchical' => true, 'label' => 'Category', 'singular_name' => 'Category'));
}

add_action('init', 'photberry_custom_post_types');

if (!function_exists('photberry_load_widgets')) 
{
	function photberry_load_widgets() 
	{
		require_once(__DIR__ . "/widgets/featured-posts.php");
		require_once(__DIR__ . "/widgets/flickr.php");
		require_once(__DIR__ . "/widgets/quick-contact.php");
	}
}
add_action('plugins_loaded', 'photberry_load_widgets');

if (!function_exists('photberry_add_widget')) 
{
	function photberry_add_widget($name) 
	{
		register_widget($name);
	}
}