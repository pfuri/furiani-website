<?php
/*
 * Created by Pixel-Mafia
 * www.pixel-mafia.com
*/
if (!class_exists('photberry_flickr'))
{
    class photberry_flickr extends WP_Widget {

        public function __construct() {
            parent::__construct( false, 'Flickr (PM)' );
        }

        function widget( $args, $instance ) {
            extract($args);

            echo $before_widget; 
            echo $before_title;
            echo esc_attr($instance['widget_title']);
            echo $after_title;

            $photberry_flickr_id = mt_rand(1000, 9999);

            echo '<div class="photberry_flickr_widget_wrapper" data-flickrid="' . (int)$photberry_flickr_id . '" data-widget_id="'. esc_attr($instance['photberry_flickr_widget_id']) .'" data-widget_number="'.esc_attr($instance['photberry_flickr_widget_number']) .'"></div>';

            echo $after_widget; 
        }

        function update( $new_instance, $old_instance ) {
            $instance = $old_instance;

            $instance['widget_title'] = esc_attr( $new_instance['widget_title'] );
            $instance['photberry_flickr_widget_number'] = absint( $new_instance['photberry_flickr_widget_number'] );
            $instance['photberry_flickr_widget_id'] = esc_attr( $new_instance['photberry_flickr_widget_id'] );

            return $instance;
        }

        function form($instance) {
            $defaultValues = array(
                'widget_title' => 'Follow on Flickr',
                'photberry_flickr_widget_number' => '6',
                'photberry_flickr_widget_id' => photberry_get_theme_mod('photberry_flickr_id')
            );
            $instance = wp_parse_args((array) $instance, $defaultValues);


        ?>
            <table class="fullwidth">
                <tr>
                    <td>Title:</td>
                    <td><input type='text' class="fullwidth" name='<?php echo esc_attr($this->get_field_name( 'widget_title' )); ?>' value='<?php echo esc_attr($instance['widget_title']); ?>'/></td>
                </tr>
                <tr>
                    <td>Flickr ID:</td>
                    <td><input type='text' class="fullwidth" name='<?php echo esc_attr($this->get_field_name( 'photberry_flickr_widget_id' )); ?>' value='<?php echo esc_attr($instance['photberry_flickr_widget_id']); ?>'/></td>
                </tr>
                <tr>
                    <td>Number:</td>
                    <td><input type='text' class="fullwidth" name='<?php echo esc_attr($this->get_field_name( 'photberry_flickr_widget_number' )); ?>' value='<?php echo esc_attr($instance['photberry_flickr_widget_number']); ?>'/></td>
                </tr>
            </table>
        <?php
        }
    }
}